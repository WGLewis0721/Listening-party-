import os, sys
sys.path.insert(0, "/tmp/build")
from build_concepts import CONCEPTS, contrast_rows, SHARED
OUT="/mnt/user-data/outputs/listening-party-concepts"

def swatch(name, hexv, fg):
    return f'<div class="sw" style="background:{hexv};color:{fg}"><b>{name}</b><span>{hexv}</span></div>'

def fg_for(h):
    r,g,b=[int(h[i:i+2],16) for i in (1,3,5)]
    return "#0b0b0c" if (0.299*r+0.587*g+0.114*b) > 140 else "#f8f6f1"

boards=[]
for c in CONCEPTS:
    sw="".join([swatch("Background",c["bg"],fg_for(c["bg"])),swatch("Surface",c["surface"],fg_for(c["surface"])),
                swatch("Ink",c["ink"],fg_for(c["ink"])),swatch("Accent",c["accent"],fg_for(c["accent"])),
                swatch("Muted",c["muted"],fg_for(c["muted"]))])
    rows="".join(f'<li>{n}: <b>{r}:1</b> {"PASS" if ok else "FAIL"}</li>' for n,r,t,ok in contrast_rows(c))
    boards.append(f'''
<section class="board">
 <header><p class="no">{c["label"]}</p><h2>{c["concept_name"]}</h2><p class="sound">{c["sound"]}</p></header>
 <div class="swatches">{sw}</div>
 <div class="pair">
  <div class="spec" style="background:{c["surface"]};color:{c["ink"]}">
   <p class="lab" style="color:{c["muted"]}">Display · {c["display_name"]}</p>
   <p class="disp" style="font-family:{c["display"]}">{c["dj"]}</p>
   <p class="lab" style="color:{c["muted"]}">Body · Manrope · labels in {c["mono"].split(",")[0].strip(chr(39))}</p>
   <p class="body">Doors 8:00 PM · Advance tickets only</p>
   <span class="cta" style="background:{c["accent"]};color:{c["accent_on"]}">Get advance tickets</span>
  </div>
  <div class="motif" style="background:{c["art_bg"]}"><span>Ticket art</span></div>
 </div>
 <div class="cols">
  <div><h3>Fixed across every week</h3><ul>
   <li>Two-column hero: copy left, ticket right</li>
   <li>Ticket rows: date, doors, reference, location</li>
   <li>Location blurred until checkout, always</li>
   <li>Accent only on the CTA and small labels</li>
   <li>One primary action, 48px minimum tap target</li></ul></div>
  <div><h3>Changes each week</h3><ul>
   <li>DJ name, vibe line and setlist moods</li>
   <li>Ticket art colors and motif</li>
   <li>Motion preset: <b>{c["motion"]}</b></li>
   <li>Price, capacity, date, payment link</li></ul>
   <p class="motion">{c["motion_note"]}</p></div>
  <div><h3>Contrast (WCAG AA)</h3><ul class="contrast">{rows}</ul></div>
 </div>
</section>''')

CSS='''*{box-sizing:border-box;margin:0;padding:0}
body{font-family:Manrope,system-ui,Arial,sans-serif;background:#111;color:#eee;padding:40px 24px;max-width:1200px;margin:auto}
h1{font-family:'Instrument Serif',Georgia,serif;font-weight:400;font-size:52px;margin-bottom:8px}
.intro{color:#aaa;max-width:70ch;margin-bottom:40px;line-height:1.6}
.board{background:#0b0b0c;border:1px solid #2e2e32;border-radius:18px;padding:28px;margin-bottom:36px}
.no{font:700 12px ui-monospace,Menlo,monospace;letter-spacing:.14em;text-transform:uppercase;color:#c8a45c}
.board h2{font-family:'Instrument Serif',Georgia,serif;font-weight:400;font-size:40px;margin:6px 0 8px}
.sound{color:#b9b4a8;max-width:80ch;line-height:1.5;margin-bottom:18px}
.swatches{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:18px}
.sw{border-radius:12px;height:110px;padding:12px;display:flex;flex-direction:column;justify-content:flex-end;font-size:12px}
.sw b{font-size:13px}.sw span{font-family:ui-monospace,Menlo,monospace;opacity:.85}
.pair{display:grid;grid-template-columns:1.2fr 1fr;gap:12px;margin-bottom:18px}
.spec{border-radius:14px;padding:26px}
.lab{font:600 11px ui-monospace,Menlo,monospace;letter-spacing:.12em;text-transform:uppercase;margin-bottom:10px}
.disp{font-size:58px;line-height:1;margin-bottom:14px;text-transform:none}
.body{font-size:15px;margin-bottom:18px}
.cta{display:inline-block;padding:12px 22px;border-radius:999px;font-weight:700}
.motif{border-radius:14px;min-height:200px;display:flex;align-items:flex-end;padding:14px}
.motif span{font:600 11px ui-monospace,Menlo,monospace;letter-spacing:.12em;text-transform:uppercase;color:#fff;background:rgba(0,0,0,.5);padding:4px 8px;border-radius:6px}
.cols{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
h3{font:700 13px Manrope,sans-serif;letter-spacing:.08em;text-transform:uppercase;color:#c8a45c;margin-bottom:10px}
ul{list-style:none;display:grid;gap:6px;color:#ccc;font-size:14px;line-height:1.5}
.motion{margin-top:10px;color:#999;font-size:13px}
.contrast li{font-family:ui-monospace,Menlo,monospace;font-size:12px}
@media(max-width:820px){.swatches{grid-template-columns:repeat(2,1fr)}.pair,.cols{grid-template-columns:1fr}}
'''
html=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Listening Room · Brand boards</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Instrument+Serif&family=Manrope:wght@400;600;700&display=swap"><style>{CSS}</style></head><body>
<h1>Listening Room · Brand boards</h1>
<p class="intro">One system, five skins. Every week the layout, ticket structure, contrast rules and the blurred-location funnel stay fixed. The DJ name, vibe, setlist, palette, art motif and motion change. The sound families are style references only: no logos, helmets, likenesses or trademarks are used, and the DJ names are fictional samples.</p>
{"".join(boards)}
</body></html>'''
open(os.path.join(OUT,"brand-boards.html"),"w",encoding="utf-8").write(html)

# Wireframes: hero storyboard at four scroll states plus a mobile frame
def frame(p, w=560, h=340):
    c=min(1,max(0,(p-.12)/.45))
    ty=(1-c)*18*h/100
    op=.35+.65*c
    rot=(1-c)*12
    return f'''<figure><div class="frame" style="width:{w}px;height:{h}px">
<div class="bar"></div>
<div class="l"><div class="sm"></div><div class="xl"></div><div class="md"></div><div class="list"><i></i><i></i><i></i><i></i></div><div class="cta"></div></div>
<div class="r" style="transform:translateY({ty:.1f}px) rotateX({rot:.1f}deg);opacity:{op:.2f}"><div class="art"></div><div class="rowsb"><i></i><i></i><i></i><i></i></div></div>
</div><figcaption>Scroll {int(p*100)}% · ticket {int(c*100)}% revealed</figcaption></figure>'''

frames="".join(frame(p) for p in [0,.3,.6,1])
mobile=f'''<figure><div class="frame m" style="width:260px;height:520px">
<div class="bar"></div><div class="l" style="grid-template-columns:1fr"><div class="sm"></div><div class="xl" style="height:40px"></div><div class="list"><i></i><i></i><i></i><i></i></div><div class="cta"></div></div>
<div class="r" style="position:relative;transform:none;opacity:1;margin:0 10px 10px;height:200px"><div class="art" style="height:70px"></div><div class="rowsb"><i></i><i></i><i></i></div></div>
</div><figcaption>Mobile 390px · reveal ends at 100%</figcaption></figure>'''
WCSS='''body{font-family:system-ui,Arial,sans-serif;background:#f4f2ee;color:#222;padding:32px;max-width:1300px;margin:auto}
h1{font-size:28px;margin-bottom:6px}p.n{color:#555;line-height:1.6;max-width:80ch;margin-bottom:24px}
.row{display:flex;flex-wrap:wrap;gap:24px;align-items:flex-start}
figure{margin:0}figcaption{font:600 12px ui-monospace,Menlo,monospace;color:#555;margin-top:8px}
.frame{position:relative;background:#fff;border:2px solid #333;border-radius:10px;padding:10px;overflow:hidden}
.bar{height:22px;background:#ddd;border-radius:4px;margin-bottom:10px}
.l{position:absolute;left:24px;top:48px;width:52%;display:grid;gap:10px}
.r{position:absolute;right:24px;top:58px;width:36%;height:60%;background:#e6e6e6;border:2px solid #888;border-radius:10px;transform-origin:50% 100%}
.l .sm{height:8px;width:30%;background:#aaa}.l .xl{height:44px;width:90%;background:#777;border-radius:4px}
.l .md{height:10px;width:70%;background:#bbb}.list{display:grid;gap:6px}.list i{display:block;height:9px;background:#ccc}
.cta{height:26px;width:55%;background:#333;border-radius:99px}
.art{height:45%;background:#999}.rowsb{padding:8px;display:grid;gap:6px}.rowsb i{display:block;height:8px;background:#bbb}
.frame.m .l{position:relative;left:auto;top:auto;width:auto}'''
wire=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Listening Room · Wireframes</title><style>{WCSS}</style></head><body>
<h1>Listening Room · Hero wireframes</h1>
<p class="n">The hero is the only section. The page is a 300vh track with a sticky stage: copy stays on the left, and the ticket rises into place as you scroll. Scroll progress drives both the headline scale and the ticket reveal (ticket starts at 12% scroll and is fully revealed at 57%). Location stays blurred until checkout. Reduced motion shows the final state with no transforms.</p>
<div class="row">{frames}</div>
<h1 style="margin-top:40px">Mobile (390px)</h1>
<div class="row">{mobile}</div>
</body></html>'''
open(os.path.join(OUT,"wireframes.html"),"w",encoding="utf-8").write(wire)
print("ok")
