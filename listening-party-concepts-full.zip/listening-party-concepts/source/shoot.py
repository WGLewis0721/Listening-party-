import asyncio, sys
from playwright.async_api import async_playwright
FILES = ["01-listening-room-base.html","03-dj-khalid-golden-hour.html","04-daft-punk-chrome.html"]
BASE="/mnt/user-data/outputs/listening-party-concepts/"
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        for f in FILES:
            for label,(w,h),frac in [("desk0",(1440,900),0.0),("desk1",(1440,900),1.0),("mob1",(390,844),1.0)]:
                pg = await b.new_page(viewport={"width":w,"height":h})
                await pg.goto("file://"+BASE+f, wait_until="domcontentloaded")
                await pg.wait_for_timeout(300)
                await pg.evaluate(f"""()=>{{const t=document.querySelector('.track');const max=t.offsetHeight-innerHeight;window.scrollTo(0,max*{frac});}}""")
                await pg.wait_for_timeout(250)
                await pg.screenshot(path=f"/tmp/shots/{f[:2]}_{label}.png")
                await pg.close()
        await b.close()
asyncio.run(main())
