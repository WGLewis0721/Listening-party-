"""Listening Room concept generator.
Edit CONCEPTS below (DJ name, vibe, setlist, palette, payment link) and re-run.
Writes one hero-only page per concept plus brand boards and a wireframe sheet."""
import os, sys

OUT = sys.argv[1] if len(sys.argv) > 1 else "/mnt/user-data/outputs/listening-party-concepts"
os.makedirs(OUT, exist_ok=True)

SHARED = dict(
    series="Listening Room", edition="Edition 01", month="November 2026",
    date="Thu, Nov 19, 2026 · 8:00 PM", doors="8:00 PM, lights low by 9:00",
    price="$25 advance", capacity=60,
    payment_url="https://example.com/checkout/listening-room-ed01",
    ref="LR-ED01-A7K2",
    venue_hidden="[Venue name] · [Street address], Montgomery, AL",
    setlist_default=None,
)

CONCEPTS = [
    dict(
        file="01-listening-room-base.html", label="Base system",
        concept_name="Concept 01 · Base system",
        sound="Mirror Finish house system: black, ivory and gold, Manrope with Instrument Serif. The base the other concepts inherit from.",
        title="Listening Room · Concept 01 · Base",
        font_url="https://fonts.googleapis.com/css2?family=Instrument+Serif&family=Manrope:wght@400;600;700&display=swap",
        display="'Instrument Serif',Georgia,serif", display_name="Instrument Serif",
        mono="ui-monospace,'SFMono-Regular',Menlo,monospace",
        bg="#0b0b0c", surface="#1c1c1f", ink="#f8f6f1", muted="#b9b4a8", accent="#c8a45c", accent_on="#0b0b0c",
        stage_bg="radial-gradient(circle at 80% 20%,rgba(200,164,92,.16),transparent 50%),var(--bg)",
        art_bg="linear-gradient(135deg,#2a2418 0%,#0b0b0c 75%)",
        motion="drift", extra_css="",
        dj="Featured DJ", vibe="Advance tickets. A room built for listening, not partying. Light snacks and drinks at the bar.",
        setlist=[("8:00","Doors","Warm lights, drinks, snacks"),("8:45","Opening set","Slow build, low tempo"),
                 ("9:45","Featured DJ","Full set, new picks, room requests"),("10:45","Close","Cool-down until last call")],
        payment_url=SHARED["payment_url"],
        motion_note="Drift: a slow background shift. Motion never changes the purchase path.",
    ),
    dict(
        file="02-deadmau5-electro.html", label="Electro-progressive",
        concept_name="Concept 02 · Electro-progressive",
        sound="Synth-forward electro: near-black, cyan signal lines, a grid motif and a beat-synced pulse on the CTA. Sound family only, no logos or likeness.",
        title="Listening Room · Concept 02 · Electro-progressive",
        font_url="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=JetBrains+Mono:wght@500;700&family=Manrope:wght@400;600;700&display=swap",
        display="'Space Grotesk',system-ui,sans-serif", display_name="Space Grotesk",
        mono="'JetBrains Mono',ui-monospace,monospace",
        bg="#05060a", surface="#0c1220", ink="#e9fbff", muted="#8ea4b3", accent="#37e6ff", accent_on="#03080c",
        stage_bg="repeating-linear-gradient(0deg,rgba(55,230,255,.07) 0 1px,transparent 1px 28px),repeating-linear-gradient(90deg,rgba(55,230,255,.07) 0 1px,transparent 1px 28px),var(--bg)",
        art_bg="linear-gradient(160deg,#0f2a36 0%,#05060a 75%)",
        motion="pulse", extra_css=".dj{text-transform:uppercase;letter-spacing:-.03em;font-weight:700}",
        dj="Nova Vale", vibe="Synths up front, lights low, every build earned. A listening room for long-form electro.",
        setlist=[("8:00","Doors","Light room, synth washes, drinks"),("8:45","Warm-up","Slow builds, 118 to 124 BPM"),
                 ("9:45","Featured set","Full-length set, new pieces, no skips"),("10:45","Last call","Cool-down and snacks until close")],
        payment_url=SHARED["payment_url"],
        motion_note="Pulse: the CTA glow beats slowly, like a kick at rest. Reduced motion turns it off.",
    ),
    dict(
        file="03-dj-khalid-golden-hour.html", label="Golden-hour vocal house",
        concept_name="Concept 03 · Golden-hour vocal house",
        sound="Warm, big-type golden hour: amber on deep brown, condensed display caps, sunset glow behind the copy. Sound family only, no logos or likeness.",
        title="Listening Room · Concept 03 · Golden-hour",
        font_url="https://fonts.googleapis.com/css2?family=Anton&family=Manrope:wght@400;600;700&display=swap",
        display="'Anton',Impact,sans-serif", display_name="Anton",
        mono="ui-monospace,Menlo,monospace",
        bg="#1a0f08", surface="#2b1a10", ink="#fff4e0", muted="#d9bd9b", accent="#f2a93b", accent_on="#1a0f08",
        stage_bg="radial-gradient(circle at 85% 15%,rgba(242,169,59,.35),transparent 50%),radial-gradient(circle at 10% 90%,rgba(242,120,40,.18),transparent 45%),var(--bg)",
        art_bg="radial-gradient(circle at 80% 20%,#f2a93b 0,#b8601e 35%,#2b1a10 75%)",
        motion="drift", extra_css=".dj{text-transform:uppercase;font-size:clamp(4rem,11vw,9rem);line-height:.88;letter-spacing:.005em}.ticket h2{text-transform:uppercase}",
        dj="Amani Sol", vibe="Warm, unhurried, built for a room that sings back. Soul-leaning house and R&B at candlelight volume.",
        setlist=[("8:00","Doors","Golden lights, cocktails, room warms up"),("8:45","Opening set","Mid-tempo grooves, 96 to 108 BPM"),
                 ("9:45","Featured set","Vocal-forward house and R&B edits"),("10:45","Close","Slow landing, last call for snacks")],
        payment_url=SHARED["payment_url"],
        motion_note="Drift: a warm glow moves behind the copy at a slow pace.",
    ),
    dict(
        file="04-daft-punk-chrome.html", label="Disco-funk chrome",
        concept_name="Concept 04 · Disco-funk chrome",
        sound="Machine-clean disco-funk: black, chrome silver, wide geometric display and a light sweep across the ticket. Sound family only, no helmets, logos or likeness.",
        title="Listening Room · Concept 04 · Disco-funk chrome",
        font_url="https://fonts.googleapis.com/css2?family=Michroma&family=Manrope:wght@400;600;700&display=swap",
        display="'Michroma',system-ui,sans-serif", display_name="Michroma",
        mono="ui-monospace,Menlo,monospace",
        bg="#0a0a0a", surface="#161616", ink="#f2f2f2", muted="#a3a3a3", accent="#d7dce3", accent_on="#0a0a0a",
        stage_bg="linear-gradient(135deg,rgba(215,220,227,.06) 25%,transparent 25% 50%,rgba(215,220,227,.06) 50% 75%,transparent 75%) 0 0/64px 64px,var(--bg)",
        art_bg="linear-gradient(135deg,#3a3f47 0%,#d7dce3 30%,#5b616b 46%,#f2f2f2 60%,#2a2e35 100%)",
        motion="sweep", extra_css=".dj{text-transform:uppercase;font-size:clamp(2.2rem,5.6vw,4.4rem);letter-spacing:.04em;line-height:1.05}",
        dj="Chrome Vector", vibe="Clean machine grooves, a chrome finish, no skips. Disco and funk, precisely cut.",
        setlist=[("8:00","Doors","Chrome lights, drinks, low room hum"),("8:45","Opening set","Disco edits, 110 to 116 BPM"),
                 ("9:45","Featured set","Funk and house, one long arc"),("10:45","Close","Last record, last call")],
        payment_url=SHARED["payment_url"],
        motion_note="Sweep: a single light band crosses the ticket art every few seconds.",
    ),
    dict(
        file="05-idris-elba-brass-night.html", label="Brass-and-night soul",
        concept_name="Concept 05 · Brass-and-night soul",
        sound="Late-night soul and deep house: deep teal-navy, brass accents, a serif display and a slow vinyl-ring motif. Sound family only, no likeness or branding.",
        title="Listening Room · Concept 05 · Brass and night",
        font_url="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Manrope:wght@400;600;700&display=swap",
        display="'Playfair Display',Georgia,serif", display_name="Playfair Display",
        mono="ui-monospace,Menlo,monospace",
        bg="#0c1a22", surface="#13293a", ink="#f4efe6", muted="#b8c4c9", accent="#d4a24c", accent_on="#0c1a22",
        stage_bg="radial-gradient(circle at 75% 45%,rgba(212,162,76,.12),transparent 45%),repeating-radial-gradient(circle at 75% 45%,rgba(212,162,76,.07) 0 1px,transparent 1px 26px),var(--bg)",
        art_bg="radial-gradient(circle at 50% 60%,#13293a 0,#0c1a22 60%),repeating-radial-gradient(circle at 50% 60%,rgba(212,162,76,.22) 0 1px,transparent 1px 9px)",
        motion="spin", extra_css=".dj{font-style:italic;font-weight:700;letter-spacing:-.01em}",
        dj="Marlowe Brass", vibe="A late set in a warm room. The record on the turntable is the centerpiece, and the room listens.",
        setlist=[("8:00","Doors","Low lamps, records on the shelf"),("8:45","Opening","Late soul and deep house, 112 to 118 BPM"),
                 ("9:45","Featured set","Long-form, one record at a time"),("10:45","Close","Last song, last call")],
        payment_url=SHARED["payment_url"],
        motion_note="Spin: the vinyl rings turn very slowly in the ticket art.",
    ),
]

def lum(h):
    r, g, b = [int(h[i:i+2], 16) / 255 for i in (1, 3, 5)]
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return .2126 * f(r) + .7152 * f(g) + .0722 * f(b)

def ratio(a, b):
    la, lb = sorted([lum(a), lum(b)], reverse=True)
    return (la + .05) / (lb + .05)

def contrast_rows(c):
    pairs = [
        ("Ink on background", c["ink"], c["bg"], 4.5),
        ("Muted text on background", c["muted"], c["bg"], 4.5),
        ("Muted text on ticket surface", c["muted"], c["surface"], 4.5),
        ("Accent text on background", c["accent"], c["bg"], 4.5),
        ("Button label on accent", c["accent_on"], c["accent"], 4.5),
    ]
    return [(n, round(ratio(x, y), 2), t, round(ratio(x, y), 2) >= t) for n, x, y, t in pairs]

SETLIST_HTML = "".join(
    f'<li><time>{t}</time><span><b>{name}</b> · {note}</span></li>' for t, name, note in []
)

TEMPLATE = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "hero_template.html"), encoding="utf-8").read()

def render(c):
    setlist = "".join(
        f'<li><time>{t}</time><span><b>{name}</b> · {note}</span></li>' for t, name, note in c["setlist"])
    vals = dict(
        TITLE=c["title"], FONT_URL=c["font_url"], BG=c["bg"], SURFACE=c["surface"], INK=c["ink"],
        MUTED=c["muted"], ACCENT=c["accent"], ACCENT_ON=c["accent_on"], DISPLAY=c["display"],
        MONO=c["mono"], STAGE_BG=c["stage_bg"], ART_BG=c["art_bg"], MOTION=c["motion"],
        EXTRA_CSS=c["extra_css"], SERIES=SHARED["series"], EDITION=SHARED["edition"],
        MONTH=SHARED["month"], CONCEPT=c["label"], DJ=c["dj"], VIBE=c["vibe"], DATE=SHARED["date"],
        DOORS=SHARED["doors"], PRICE=SHARED["price"], CAPACITY=str(SHARED["capacity"]),
        PAYMENT_URL=c["payment_url"], REF=SHARED["ref"], VENUE_HIDDEN=SHARED["venue_hidden"],
        SETLIST=setlist,
    )
    html = TEMPLATE
    for k, v in vals.items():
        html = html.replace("@@" + k + "@@", v)
    assert "@@" not in html, "unfilled placeholder"
    return html

if __name__ == "__main__":
    report = []
    for c in CONCEPTS:
        with open(os.path.join(OUT, c["file"]), "w", encoding="utf-8") as fh:
            fh.write(render(c))
        report.append((c["label"], contrast_rows(c)))
    for label, rows in report:
        print(f"\n{label}")
        for n, r, t, ok in rows:
            print(f"  {n}: {r}:1 (need {t}:1) {'PASS' if ok else 'FAIL'}")
    print("\nwritten:", OUT)
