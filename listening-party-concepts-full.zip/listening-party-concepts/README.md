# Listening Room concepts

Start with `index.html`. It links to the five concepts, brand boards, wireframes and the UX audit.

- `01` to `05` are the hero-only concept pages. Scroll to reveal the ticket. Each CTA links to a placeholder payment URL.
- `brand-boards.html` shows the five systems with swatches, type, contrast and what stays fixed week to week.
- `wireframes.html` shows the scroll states and the mobile frame.
- `UX-AUDIT.md` lists what was checked and what is still open.
- `source/` regenerates everything. Edit the `CONCEPTS` list in `build_concepts.py` (DJ name, vibe, setlist, palette, payment link, date, price) and the shared event fields in `SHARED`, then run:

      python3 build_concepts.py <out-dir>
      python3 make_docs.py

Before sending to anyone, replace the payment URL, the date and the venue placeholders, and confirm the price and capacity.
